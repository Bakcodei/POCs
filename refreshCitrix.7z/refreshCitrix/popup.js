console.log('loaded to page');
setInterval(function(){
  window.location.reload();
  console.log('clicked to page');
},180000);